module com.example.pstu_admission {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    exports com.example.pstu_admission;
    exports com.example.pstu_admission.utils; // Export your main package
}
