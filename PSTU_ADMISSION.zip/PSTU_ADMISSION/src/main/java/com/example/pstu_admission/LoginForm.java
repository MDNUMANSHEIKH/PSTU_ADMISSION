package com.example.pstu_admission;

import com.example.pstu_admission.utils.DatabaseHelper;
import com.example.pstu_admission.utils.SessionManager;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LoginForm {
    private final VBox root;

    public LoginForm() {
        root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-font-family: Arial;");

        Label title = new Label("Patuakhali Science And Technology University, Patuakhali\n\n                                         Login");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        HBox emailBox = new HBox(10);
        emailBox.setAlignment(Pos.CENTER);
        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();
        emailBox.getChildren().addAll(emailLabel, emailField);

        HBox passwordBox = new HBox(10);
        passwordBox.setAlignment(Pos.CENTER);
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        passwordBox.getChildren().addAll(passwordLabel, passwordField);

        Button submitButton = new Button("Submit");
        submitButton.setDisable(true);

        Button forgetPasswordButton = new Button("Forget Password");
        Button signUpButton = new Button("Sign Up");

        submitButton.setOnAction(e -> handleLogin(emailField.getText(), passwordField.getText()));
        forgetPasswordButton.setOnAction(e -> openForgetPassword());
        signUpButton.setOnAction(e -> openSignUp());

        emailField.textProperty().addListener((obs, oldText, newText) -> validateFields(emailField, passwordField, submitButton));
        passwordField.textProperty().addListener((obs, oldText, newText) -> validateFields(emailField, passwordField, submitButton));

        root.getChildren().addAll(title, emailBox, passwordBox, submitButton, forgetPasswordButton, signUpButton);
    }

    public VBox getRoot() {
        return root;
    }

    private void validateFields(TextField emailField, PasswordField passwordField, Button submitButton) {
        boolean isEmailFilled = !emailField.getText().trim().isEmpty();
        boolean isPasswordFilled = !passwordField.getText().trim().isEmpty();
        submitButton.setDisable(!(isEmailFilled && isPasswordFilled));
    }

    private void handleLogin(String email, String password) {
        System.out.println("Attempting to log in with email: " + email);
        boolean isValid = DatabaseHelper.validateLogin(email, password);
        if (isValid) {
            SessionManager.getInstance().setLoggedInEmail(email);
            openProfile();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid email or password.");
            alert.showAndWait();
        }
    }

    private void openForgetPassword() {
        ForgetPasswordForm forgetPasswordForm = new ForgetPasswordForm();
        switchScene(forgetPasswordForm.getRoot());
    }

    private void openSignUp() {
        SignUpForm signUpForm = new SignUpForm();
        switchScene(signUpForm.getRoot());
    }

    private void openProfile() {
        ProfileForm profileForm = new ProfileForm();
        switchScene(profileForm.getRoot());
    }

    private void switchScene(VBox newRoot) {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.getScene().setRoot(newRoot);
    }
}
