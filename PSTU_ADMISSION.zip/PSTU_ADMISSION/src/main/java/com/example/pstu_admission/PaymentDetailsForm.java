package com.example.pstu_admission;

import com.example.pstu_admission.utils.DatabaseHelper;
import com.example.pstu_admission.utils.SessionManager;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PaymentDetailsForm {
    private final VBox root;

    public PaymentDetailsForm(String paymentMethod) {
        root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-font-family: Arial;");

        Label title = new Label("Payment by " + paymentMethod);
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Label contactInfo = new Label(paymentMethod + " Number +8801721328513 (Pay-Bill)");
        contactInfo.setStyle("-fx-font-size: 12px; -fx-text-fill: gray;");

        HBox phoneBox = new HBox(10);
        phoneBox.setAlignment(Pos.CENTER);

        Label phoneLabel = new Label("Phone Number:");
        TextField phoneField = new TextField();
        phoneField.setPromptText("Number");

        phoneBox.getChildren().addAll(phoneLabel, phoneField);

        HBox taxIdBox = new HBox(10);
        taxIdBox.setAlignment(Pos.CENTER);

        Label taxIdLabel = new Label("Tax ID:");
        TextField taxIdField = new TextField();
        taxIdField.setPromptText("Tax ID");

        taxIdBox.getChildren().addAll(taxIdLabel, taxIdField);

        Button submitButton = new Button("Pay");

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> goBack());

        submitButton.setOnAction(e -> handlePaymentSubmission(phoneField, taxIdField, paymentMethod));

        root.getChildren().addAll(title, contactInfo, phoneBox, taxIdBox, submitButton, backButton);
    }

    public VBox getRoot() {
        return root;
    }

    private void handlePaymentSubmission(TextField phoneField, TextField taxIdField, String paymentMethod) {
        String phoneNumber = phoneField.getText();
        String taxId = taxIdField.getText();

        if (phoneNumber.isEmpty() || !phoneNumber.matches("^\\+8801\\d{9}$")) {
            showAlert(Alert.AlertType.ERROR, "+8801XXXXXXXX");
            return;
        }

        if (!taxId.startsWith("TAX")) {
            showAlert(Alert.AlertType.ERROR, "start with 'TAX'");
            return;
        }

        if (isTaxIdExists(taxId)) {
            showAlert(Alert.AlertType.ERROR, "Invalid Tax ID");
            return;
        }

        String studentEmail = SessionManager.getInstance().getLoggedInEmail();

        String query = "INSERT INTO payments (student_email, payment_method, phone_number, tax_id) VALUES (?, ?, ?, ?)";
        boolean success = DatabaseHelper.executeUpdate(query, studentEmail, paymentMethod, phoneNumber, taxId);

        if (success) {
            DatabaseHelper.updateReAdmissionStatus(studentEmail);
            showAlert(Alert.AlertType.INFORMATION, "Paid via " + paymentMethod);
            goBackToProfile();
        } else {
            showAlert(Alert.AlertType.ERROR, "Payment failed.");
        }
    }

    private boolean isTaxIdExists(String taxId) {
        String query = "SELECT tax_id FROM payments WHERE tax_id = ?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, taxId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message);
        alert.showAndWait();
    }

    private void goBack() {
        PaymentMethodsForm paymentMethodsForm = new PaymentMethodsForm();
        switchScene(paymentMethodsForm.getRoot());
    }

    private void goBackToProfile() {
        ProfileForm profileForm = new ProfileForm();
        switchScene(profileForm.getRoot());
    }

    private void switchScene(VBox newRoot) {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.getScene().setRoot(newRoot);
    }
}
