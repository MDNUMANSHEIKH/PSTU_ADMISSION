package com.example.pstu_admission;

import com.example.pstu_admission.utils.DatabaseHelper;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SignUpForm {
    private final VBox root;

    public SignUpForm() {
        root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-font-family: Arial;");

        Label title = new Label("Patuakhali Science And Technology University\n\n                                 Sign Up");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        HBox fullNameBox = new HBox(10);
        fullNameBox.setAlignment(Pos.CENTER);
        Label fullNameLabel = new Label("Full Name:");
        TextField fullNameField = new TextField();
        fullNameBox.getChildren().addAll(fullNameLabel, fullNameField);

        HBox emailBox = new HBox(10);
        emailBox.setAlignment(Pos.CENTER);
        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();
        emailField.setPromptText("@pstu.ac.bd");
        emailBox.getChildren().addAll(emailLabel, emailField);

        HBox idBox = new HBox(10);
        idBox.setAlignment(Pos.CENTER);
        Label idLabel = new Label("ID:");
        TextField idField = new TextField();
        idField.setPromptText("7 digits");
        idBox.getChildren().addAll(idLabel, idField);

        HBox regBox = new HBox(10);
        regBox.setAlignment(Pos.CENTER);
        Label regLabel = new Label("Registration Number:");
        TextField regField = new TextField();
        regField.setPromptText("5 digits");
        regBox.getChildren().addAll(regLabel, regField);

        HBox sessionBox = new HBox(10);
        sessionBox.setAlignment(Pos.CENTER);
        Label sessionLabel = new Label("Session:");
        TextField sessionField = new TextField();
        sessionField.setPromptText("e.g., 2020-21");
        sessionBox.getChildren().addAll(sessionLabel, sessionField);

        HBox admissionDateBox = new HBox(10);
        admissionDateBox.setAlignment(Pos.CENTER);
        Label admissionDateLabel = new Label("Admission Date:");
        TextField admissionDateField = new TextField();
        admissionDateField.setPromptText("YYYY-MM-DD");
        admissionDateBox.getChildren().addAll(admissionDateLabel, admissionDateField);

        HBox passwordBox = new HBox(10);
        passwordBox.setAlignment(Pos.CENTER);
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("5 to 126");
        passwordBox.getChildren().addAll(passwordLabel, passwordField);

        HBox confirmPasswordBox = new HBox(10);
        confirmPasswordBox.setAlignment(Pos.CENTER);
        Label confirmPasswordLabel = new Label("Confirm Password:");
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Same as New Password");
        confirmPasswordBox.getChildren().addAll(confirmPasswordLabel, confirmPasswordField);

        Button submitButton = new Button("Submit");
        Button backButton = new Button("Back");

        submitButton.setOnAction(e -> handleSignUp(fullNameField, emailField, idField, regField, sessionField, admissionDateField, passwordField, confirmPasswordField));
        backButton.setOnAction(e -> goBackToLogin());

        root.getChildren().addAll(title, fullNameBox, emailBox, idBox, regBox, sessionBox, admissionDateBox, passwordBox, confirmPasswordBox, submitButton, backButton);
    }

    public VBox getRoot() {
        return root;
    }

    private void handleSignUp(TextField fullNameField, TextField emailField, TextField idField, TextField regField, TextField sessionField, TextField admissionDateField, PasswordField passwordField, PasswordField confirmPasswordField) {
        String fullName = fullNameField.getText().trim();
        String email = emailField.getText().trim();
        String id = idField.getText().trim();
        String reg = regField.getText().trim();
        String session = sessionField.getText().trim();
        String admissionDate = admissionDateField.getText().trim();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        if (fullName.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Full Name");
            return;
        }
        else if (email.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Email");
            return;
        }
        else if (id.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill ID");
            return;
        }
        else if (reg.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Registration Number");
            return;
        }
        else if (session.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Session");
            return;
        }
        else if (admissionDate.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Admission Date");
            return;
        }
        else if (password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Password");
            return;
        }
        else if (confirmPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Confirm Password");
            return;
        }

        if (!validateEmail(email)) {
            showAlert(Alert.AlertType.ERROR, "Format ugXXXXXXX@pstu.ac.bd");
            return;
        }

        if (!password.equals(confirmPassword)) {
            showAlert(Alert.AlertType.ERROR, "Passwords do not match.");
            return;
        }

        if (!validatePassword(password)) {
            passwordField.setStyle("-fx-border-color: red; -fx-border-width: 2px;");
            showAlert(Alert.AlertType.ERROR, "0-9, a-z, A-Z, and special character and 5 to 126.");
            return;
        } else {
            passwordField.setStyle(null);
        }

        if (session.length() != 7) {
            showAlert(Alert.AlertType.ERROR, "Invalid Session.");
            return;
        }

        if (reg.length() != 5) {
            showAlert(Alert.AlertType.ERROR, "Invalid Registration.");
            return;
        }

        if (isEmailExists(email)) {
            showAlert(Alert.AlertType.ERROR, "Email is already registered.");
            return;
        }

        if (isIdExists(id)) {
            showAlert(Alert.AlertType.ERROR, "ID is already registered.");
            return;
        }

        if (isRegNumberExists(reg)) {
            showAlert(Alert.AlertType.ERROR, "Registration number is already registered.");
            return;
        }

        String query = "INSERT INTO students (full_name, email, student_id, registration_number, session, admission_date, password, re_admission_paid) VALUES (?, ?, ?, ?, ?, ?, ?, FALSE)";
        boolean success = DatabaseHelper.executeUpdate(query, fullName, email, id, reg, session, admissionDate, password);

        System.out.println("Executing query: " + query);
        System.out.println("Parameters: " + fullName + ", " + email + ", " + id + ", " + reg + ", " + session + ", " + admissionDate + ", " + password); // Debugging print statement

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Sign Up Successful!");
            goBackToLogin();
        } else {
            showAlert(Alert.AlertType.ERROR, "Sign Up Failed.");
        }
    }

    private boolean validateEmail(String email) {
        String emailPattern = "^ug\\d{7}@pstu\\.ac\\.bd$";
        return email.matches(emailPattern);
    }

    private boolean isEmailExists(String email) {
        String query = "SELECT email FROM students WHERE email = ?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean isIdExists(String id) {
        String query = "SELECT student_id FROM students WHERE student_id = ?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean isRegNumberExists(String reg) {
        String query = "SELECT registration_number FROM students WHERE registration_number = ?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, reg);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean validatePassword(String password) {
        String passwordPattern = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!]).{5,126}$";
        return password.matches(passwordPattern);
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message);
        alert.showAndWait();
    }

    private void goBackToLogin() {
        LoginForm loginForm = new LoginForm();
        switchScene(loginForm.getRoot());
    }

    private void switchScene(VBox newRoot) {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.getScene().setRoot(newRoot);
    }
}
