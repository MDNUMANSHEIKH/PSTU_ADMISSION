package com.example.pstu_admission;

import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class PaymentMethodsForm {
    private final VBox root;

    public PaymentMethodsForm() {
        root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-font-family: Arial;");

        Label title = new Label("Select Payment Method");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Button bkashButton = new Button("Bkash");
        Button nagadButton = new Button("Nagad");
        Button rocketButton = new Button("Rocket");

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> goBack());

        bkashButton.setOnAction(e -> openPaymentDetails("Bkash"));
        nagadButton.setOnAction(e -> openPaymentDetails("Nagad"));
        rocketButton.setOnAction(e -> openPaymentDetails("Rocket"));

        root.getChildren().addAll(title, bkashButton, nagadButton, rocketButton, backButton);
    }

    public VBox getRoot() {
        return root;
    }

    private void openPaymentDetails(String paymentMethod) {
        PaymentDetailsForm paymentDetailsForm = new PaymentDetailsForm(paymentMethod);
        switchScene(paymentDetailsForm.getRoot());
    }

    private void goBack() {
        ReAdmissionForm reAdmissionForm = new ReAdmissionForm();
        switchScene(reAdmissionForm.getRoot());
    }

    private void switchScene(VBox newRoot) {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.getScene().setRoot(newRoot);
    }
}
