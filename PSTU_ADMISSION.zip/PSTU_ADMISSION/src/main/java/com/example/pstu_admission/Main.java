package com.example.pstu_admission;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        LoginForm loginForm = new LoginForm();
        Scene scene = new Scene(loginForm.getRoot(), 400, 300);
        primaryStage.setTitle("PSTU Admission System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
