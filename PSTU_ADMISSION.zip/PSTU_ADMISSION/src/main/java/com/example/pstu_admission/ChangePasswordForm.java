package com.example.pstu_admission;

import com.example.pstu_admission.utils.DatabaseHelper;
import com.example.pstu_admission.utils.SessionManager;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ChangePasswordForm {
    private final VBox root;

    public ChangePasswordForm() {
        root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-font-family: Arial;");

        Label title = new Label("Change Password");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        HBox newPasswordBox = new HBox(10);
        newPasswordBox.setAlignment(Pos.CENTER);
        Label newPasswordLabel = new Label("New Password:");
        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("Must be strong!");
        newPasswordBox.getChildren().addAll(newPasswordLabel, newPasswordField);

        HBox confirmPasswordBox = new HBox(10);
        confirmPasswordBox.setAlignment(Pos.CENTER);
        Label confirmPasswordLabel = new Label("Confirm Password:");
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Same as New Password.");
        confirmPasswordBox.getChildren().addAll(confirmPasswordLabel, confirmPasswordField);

        Button submitButton = new Button("Submit");

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> goBack());

        submitButton.setOnAction(e -> handlePasswordChange(newPasswordField, confirmPasswordField));

        root.getChildren().addAll(title, newPasswordBox, confirmPasswordBox, submitButton, backButton);
    }

    public VBox getRoot() {
        return root;
    }

    private void handlePasswordChange(PasswordField newPasswordField, PasswordField confirmPasswordField) {
        String newPassword = newPasswordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        String email = SessionManager.getInstance().getLoggedInEmail();

        if (newPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill New Password.");
            return;
        }
        else if (confirmPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Confirm Password.");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            showAlert(Alert.AlertType.ERROR, "Passwords not match.");
            return;
        }

        if (newPassword.equals(getCurrentPassword(email))) {
            showAlert(Alert.AlertType.ERROR, "Password same as old Password.");
            return;
        }

        String query = "UPDATE students SET password = ? WHERE email = ?";
        boolean success = DatabaseHelper.executeUpdate(query, newPassword, email);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Password Changed Successfully!");
        } else {
            showAlert(Alert.AlertType.ERROR, "Password Change Failed.");
        }
    }

    private String getCurrentPassword(String email) {
        String query = "SELECT password FROM students WHERE email = ?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("password");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message);
        alert.showAndWait();
    }

    private void goBack() {
        ProfileForm profileForm = new ProfileForm();
        switchScene(profileForm.getRoot());
    }

    private void switchScene(VBox newRoot) {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.getScene().setRoot(newRoot);
    }
}
