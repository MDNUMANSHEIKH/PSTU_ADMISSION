package com.example.pstu_admission;

import com.example.pstu_admission.utils.DatabaseHelper;
import com.example.pstu_admission.utils.SessionManager;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProfileForm {
    private final VBox root;

    public ProfileForm() {
        root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-font-family: Arial;");

        Label title = new Label("Student Profile");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        String studentEmail = SessionManager.getInstance().getLoggedInEmail();
        String name = getStudentData(studentEmail, "full_name");
        String email = getStudentData(studentEmail, "email");
        String id = getStudentData(studentEmail, "student_id");
        String reg = getStudentData(studentEmail, "registration_number");
        String session = getStudentData(studentEmail, "session");
        String admissionDate = getStudentData(studentEmail, "admission_date");
        String level = calculateLevel(id);
        String semester = calculateSemester(admissionDate);

        TableView<ProfileDetail> tableView = new TableView<>();
        tableView.setPrefWidth(400);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<ProfileDetail, String> attributeColumn = new TableColumn<>("Attribute");
        attributeColumn.setCellValueFactory(cellData -> cellData.getValue().attributeProperty());
        attributeColumn.setPrefWidth(200);

        TableColumn<ProfileDetail, String> valueColumn = new TableColumn<>("Value");
        valueColumn.setCellValueFactory(cellData -> cellData.getValue().valueProperty());
        valueColumn.setPrefWidth(200);

        tableView.getColumns().addAll(attributeColumn, valueColumn);

        tableView.getItems().addAll(
                new ProfileDetail("Name", name),
                new ProfileDetail("Email", email),
                new ProfileDetail("ID", id),
                new ProfileDetail("Registration Number", reg),
                new ProfileDetail("Session", session),
                new ProfileDetail("Current Level", level),
                new ProfileDetail("Current Semester", semester)
        );

        Button changePasswordButton = new Button("Change Password");
        changePasswordButton.setOnAction(e -> openChangePassword());

        Button reAdmissionButton = new Button("Re-Admission");
        reAdmissionButton.setOnAction(e -> openReAdmission());

        reAdmissionButton.setVisible(!DatabaseHelper.isReAdmissionPaid(studentEmail));

        Button backButton = new Button("Back to Login");
        backButton.setOnAction(e -> goBackToLogin());

        root.getChildren().addAll(title, tableView, changePasswordButton, reAdmissionButton, backButton);
    }

    public VBox getRoot() {
        return root;
    }

    private void goBackToLogin() {
        LoginForm loginForm = new LoginForm();
        switchScene(loginForm.getRoot());
    }

    private void openChangePassword() {
        ChangePasswordForm changePasswordForm = new ChangePasswordForm();
        switchScene(changePasswordForm.getRoot());
    }

    private void openReAdmission() {
        ReAdmissionForm reAdmissionForm = new ReAdmissionForm();
        switchScene(reAdmissionForm.getRoot());
    }

    private String calculateLevel(String id) {
        if (id == null || id.length() < 2) {
            System.err.println("Invalid student ID: " + id);
            return "";
        }

        int idYear;
        try {
            idYear = Integer.parseInt(id.substring(0, 2));
        } catch (NumberFormatException e) {
            System.err.println("Error parsing ID year: " + e.getMessage());
            return "";
        }

        int currentYear = java.time.Year.now().getValue() % 100;
        int levelCalc = currentYear - (idYear + 1);

        if (levelCalc <= 1) return "Level 1";
        if (levelCalc <= 2) return "Level 2";
        if (levelCalc <= 3) return "Level 3";
        return "Level 4";
    }

    private String calculateSemester(String admissionDate) {
        if (admissionDate == null || admissionDate.isEmpty()) return "";
        int admissionMonth = Integer.parseInt(admissionDate.substring(5, 7));
        int currentMonth = java.time.YearMonth.now().getMonthValue();
        int monthsPassed = currentMonth - admissionMonth;

        int semester = (monthsPassed / 6) + 1;
        return "Semester " + semester;
    }

    private void switchScene(VBox newRoot) {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.getScene().setRoot(newRoot);
    }

    private String getStudentData(String email, String field) {
        String query = "SELECT " + field + " FROM students WHERE email = ?";
        try (Connection conn = DatabaseHelper.connect()) {
            assert conn != null;
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, email);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getString(field);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static class ProfileDetail {
        private final SimpleStringProperty attribute;
        private final SimpleStringProperty value;

        public ProfileDetail(String attribute, String value) {
            this.attribute = new SimpleStringProperty(attribute);
            this.value = new SimpleStringProperty(value);
        }

        public SimpleStringProperty attributeProperty() {
            return attribute;
        }

        public SimpleStringProperty valueProperty() {
            return value;
        }
    }
}
