package com.example.pstu_admission.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DatabaseHelper {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/university_portal";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static Connection connect() {
        try {
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean validateLogin(String email, String password) {
        String query = "SELECT * FROM students WHERE email = ? AND password = ?";
        try (Connection conn = connect()) {
            assert conn != null;
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, email);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();
                boolean result = rs.next();
                System.out.println("Login query result: " + result);
                return result;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean executeUpdate(String query, Object... params) {
        try (Connection conn = connect()) {
            assert conn != null;
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                for (int i = 0; i < params.length; i++) {
                    stmt.setObject(i + 1, params[i]);
                }
                int rowsAffected = stmt.executeUpdate();
                System.out.println("Rows affected: " + rowsAffected);
                return rowsAffected > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void updateReAdmissionStatus(String email) {
        String query = "UPDATE students SET re_admission_paid = TRUE WHERE email = ?";
        executeUpdate(query, email);
    }

    public static boolean isReAdmissionPaid(String email) {
        String query = "SELECT re_admission_paid FROM students WHERE email = ?";
        try (Connection conn = connect()) {
            assert conn != null;
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, email);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getBoolean("re_admission_paid");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
