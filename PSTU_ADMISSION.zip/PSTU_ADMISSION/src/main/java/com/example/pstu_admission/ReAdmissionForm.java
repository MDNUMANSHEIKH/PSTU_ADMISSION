package com.example.pstu_admission;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ReAdmissionForm {
    private final VBox root;

    public ReAdmissionForm() {
        root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-font-family: Arial;");

        Label title = new Label("Re-Admission Fee Receipt");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        TableView<FeeDetail> tableView = new TableView<>();
        tableView.setPrefWidth(300);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<FeeDetail, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());
        descriptionColumn.setPrefWidth(200);

        TableColumn<FeeDetail, String> amountColumn = new TableColumn<>("Amount (tk)");
        amountColumn.setCellValueFactory(cellData -> cellData.getValue().amountProperty());
        amountColumn.setPrefWidth(100);

        tableView.getColumns().addAll(descriptionColumn, amountColumn);

        tableView.getItems().addAll(
                new FeeDetail("Admission Fee", "300"),
                new FeeDetail("Enrollment Fee", "200"),
                new FeeDetail("Course Fee", "1575"),
                new FeeDetail("General Fee", "120"),
                new FeeDetail("Admission Fee with Credit", "1170"),
                new FeeDetail("Hall Student Union Fee", "150")
        );

        Label totalLabel = new Label("Total: 4915 tk");

        Button payBillButton = new Button("Pay Bill");
        payBillButton.setOnAction(e -> openPaymentMethods());

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> goBack());

        root.getChildren().addAll(title, tableView, totalLabel, payBillButton, backButton);
    }

    public VBox getRoot() {
        return root;
    }

    private void openPaymentMethods() {
        PaymentMethodsForm paymentMethodsForm = new PaymentMethodsForm();
        switchScene(paymentMethodsForm.getRoot());
    }

    private void goBack() {
        ProfileForm profileForm = new ProfileForm();
        switchScene(profileForm.getRoot());
    }

    private void switchScene(VBox newRoot) {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.getScene().setRoot(newRoot);
    }

    public static class FeeDetail {
        private final SimpleStringProperty description;
        private final SimpleStringProperty amount;

        public FeeDetail(String description, String amount) {
            this.description = new SimpleStringProperty(description);
            this.amount = new SimpleStringProperty(amount);
        }

        public SimpleStringProperty descriptionProperty() {
            return description;
        }

        public SimpleStringProperty amountProperty() {
            return amount;
        }
    }
}
