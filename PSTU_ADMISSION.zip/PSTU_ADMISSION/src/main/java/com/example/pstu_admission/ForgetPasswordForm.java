package com.example.pstu_admission;

import com.example.pstu_admission.utils.DatabaseHelper;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ForgetPasswordForm {
    private final VBox root;

    public ForgetPasswordForm() {
        root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-padding: 20; -fx-font-family: Arial;");

        Label title = new Label("Recover Password");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        HBox emailBox = new HBox(10);
        emailBox.setAlignment(Pos.CENTER);
        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();
        emailField.setPromptText("@pstu.ac.bd");
        emailBox.getChildren().addAll(emailLabel, emailField);

        HBox newPasswordBox = new HBox(10);
        newPasswordBox.setAlignment(Pos.CENTER);
        Label newPasswordLabel = new Label("New Password:");
        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("Must be strong!");
        newPasswordBox.getChildren().addAll(newPasswordLabel, newPasswordField);

        HBox confirmPasswordBox = new HBox(10);
        confirmPasswordBox.setAlignment(Pos.CENTER);
        Label confirmPasswordLabel = new Label("Confirm Password:");
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Same as New Password.");
        confirmPasswordBox.getChildren().addAll(confirmPasswordLabel, confirmPasswordField);

        Button submitButton = new Button("Submit");

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> goBack());

        submitButton.setOnAction(e -> handlePasswordReset(emailField, newPasswordField, confirmPasswordField));

        root.getChildren().addAll(title, emailBox, newPasswordBox, confirmPasswordBox, submitButton, backButton);
    }

    public VBox getRoot() {
        return root;
    }

    private void handlePasswordReset(TextField emailField, PasswordField newPasswordField, PasswordField confirmPasswordField) {
        String email = emailField.getText().trim();
        String newPassword = newPasswordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        if (email.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Email Field.");
            return;
        }
        else if (newPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill New Password Field.");
            return;
        }
       else  if (confirmPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Fill Confirm Password Field.");
            return;
        }

        if (!email.endsWith("@pstu.ac.bd")) {
            showAlert(Alert.AlertType.ERROR, "Domain @pstu.ac.bd Required");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            showAlert(Alert.AlertType.ERROR, "Passwords not match.");
            return;
        }

        if (newPassword.equals(getCurrentPassword(email))) {
            showAlert(Alert.AlertType.ERROR, "Password same as old Password.");
            return;
        }

        String query = "UPDATE students SET password = ? WHERE email = ?";
        boolean success = DatabaseHelper.executeUpdate(query, newPassword, email);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Password Reset Successful!");
        } else {
            showAlert(Alert.AlertType.ERROR, "Password Reset Failed.");
        }
    }

    private String getCurrentPassword(String email) {
        String query = "SELECT password FROM students WHERE email = ?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("password");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message);
        alert.showAndWait();
    }

    private void goBack() {
        LoginForm loginForm = new LoginForm();
        switchScene(loginForm.getRoot());
    }

    private void switchScene(VBox newRoot) {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.getScene().setRoot(newRoot);
    }
}
